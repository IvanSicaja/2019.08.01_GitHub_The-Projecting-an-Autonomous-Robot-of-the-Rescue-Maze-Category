import time
start_time=time.time()
time.sleep(5)
end_time=time.time()
print(end_time-start_time)