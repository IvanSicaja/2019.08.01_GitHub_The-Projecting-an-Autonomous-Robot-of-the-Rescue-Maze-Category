#include "Robot_Gibanje.h"

// Object definition
Adafruit_BNO055 gyroscope = Adafruit_BNO055(55); // Gyroscope object

const float Maze_Plate_Lenght = 325;                                                                                                                      //Dimensions of maze palte
const float Front_Snesor_Distance_In_Millimeters_From_Robot_Center_Point = 72;                                                                            //Distance from axis of robot center point circuit design
const float Side_Snesor_Distance_In_Millimeters_From_Robot_Center_Point = 15;                                                                             //Distance from axis of robot center point circuit design
const float Optimal_Stop_Front_Distance_For_Center_Robot = ((Maze_Plate_Lenght / 2) - Front_Snesor_Distance_In_Millimeters_From_Robot_Center_Point) / 10; //Distance for center robot Optimal = 78 mm
const float Optimal_Side_Distance_For_Center_Robot = ((Maze_Plate_Lenght / 2) - Side_Snesor_Distance_In_Millimeters_From_Robot_Center_Point) / 10;        //Distance for center robot Optimal = 135 mm
const float Check_Is_Front_Walls_Opend = 193;                                                                                                             //Variable for checking is walls opend
const float Check_Is_Side_Walls_Opend = 245;                                                                                                              //Variable for checking is walls opend

int Setpoint1; // Orientetion value variable which robot follow

///////// Color sensor parametters ///////////////
// Calibration Values - Get these from Calibration Sketch
int redMin = 20;    // Red minimum value
int redMax = 217;   // Red maximum value
int greenMin = 20;  // Green minimum value
int greenMax = 220; // Green maximum value
int blueMin = 16;   // Blue minimum value
int blueMax = 171;  // Blue maximum value
// Variables for Color Pulse Width Measurements
int redPW = 0;
int greenPW = 0;
int bluePW = 0;
// Variables for final Color values
int redValue;
int greenValue;
int blueValue;

ROBOT_GIBANJE::ROBOT_GIBANJE()
{ // Constructor
}

ROBOT_GIBANJE::~ROBOT_GIBANJE()
{ // Destructor
}

void ROBOT_GIBANJE::Setup_For_All_Components()
{

        delay(1000); // Needed delay for succesed setup

        Serial.println("We are inside SetupZaSveKomponente() function.");

        pinMode(FORWARD1_AN_PIN, INPUT);
        pinMode(FORWARD2_AN_PIN, INPUT);
        pinMode(LEFT1_AN_PIN, INPUT);
        pinMode(LEFT2_AN_PIN, INPUT);
        pinMode(RIGHT1_AN_PIN, INPUT);
        pinMode(RIGHT2_AN_PIN, INPUT);

        pinMode(LEFT_THERMAL_CAM_OUT_PIN, INPUT);
        pinMode(RIGHT_THERMAL_CAM_OUT_PIN, INPUT);

        pinMode(SPEED_FRONT_LEFT_MOTOR_PIN, OUTPUT);
        pinMode(DIRECTION_FRONT_LEFT_MOTOR_PIN, OUTPUT);
        pinMode(SPEED_FRONT_RIGHT_MOTOR_PIN, OUTPUT);
        pinMode(DIRECTION_FRONT_RIGHT_MOTOR_PIN, OUTPUT);
        pinMode(SPEED_BACK_LEFT_MOTOR_PIN, OUTPUT);
        pinMode(DIRECTION_BACK_LEFT_MOTOR_PIN, OUTPUT);
        pinMode(SPEED_BACK_RIGHT_MOTOR_PIN, OUTPUT);
        pinMode(DIRECTION_BACK_RIGHT_MOTOR_PIN, OUTPUT);

        //pinMode(ELECTROMAGNET_PIN1, OUTPUT);
        //pinMode(ELECTROMAGNET_PIN2, OUTPUT);

        // ##### Color sensor pins ##### //
        // Set S0 - S3 as outputs
        pinMode(S0, OUTPUT);
        pinMode(S1, OUTPUT);
        pinMode(S2, OUTPUT);
        pinMode(S3, OUTPUT);

        // Set Sensor output as input
        pinMode(sensorOut, INPUT);

        // Set Frequency scaling to 20%
        digitalWrite(S0, HIGH);
        digitalWrite(S1, LOW);

        //Encoders pin setup
        pinMode(ENCODER_LEFT_A_OUT, INPUT);
        pinMode(ENCODER_LEFT_B_OUT, INPUT);
        pinMode(ENCODER_RIGHT_A_OUT, INPUT);
        pinMode(ENCODER_RIGHT_B_OUT, INPUT);

        if (!gyroscope.begin())
        {
                // There was a problem detecting the BNO055 ... check your connections
                Serial.print(F("Ooops, no BNO055 detected ... Check your wiring or I2C ADDR!"));

                while (1)
                        ;
        }
        delay(1000);
        gyroscope.setExtCrystalUse(true);

        Serial.println("Serijska komunikacija uspostavljena");
        Serial.println("######################################################");
}

void ROBOT_GIBANJE::SetMotorSpeedAndDirection(uint8_t SPEED_PIN, uint8_t DIRECTION_PIN, int motor_speed)
{

        if ((motor_speed >= (-100)) && (motor_speed <= 100))
        { // motor_speed needs to be from -100 to 100
                if (motor_speed > 0)
                { // when this number is negative motor goes forward, when negative it goes backwards
                        motor_speed = map(motor_speed, 0, 100, 0, 255);
                        digitalWrite(DIRECTION_PIN, LOW);
                        analogWrite(SPEED_PIN, motor_speed);
                }
                else if (motor_speed < 0)
                {
                        motor_speed = map(motor_speed, -100, 0, 0, 255);
                        digitalWrite(DIRECTION_PIN, HIGH);
                        analogWrite(SPEED_PIN, motor_speed);
                }
                else
                {
                        analogWrite(DIRECTION_PIN, 0);
                        analogWrite(SPEED_PIN, 0);
                }
        }
}

void ROBOT_GIBANJE::Go_Forward(int left_motor_speed, int right_motor_speed)
{
        // Default speed is maximum when you don't send any value to function

        SetMotorSpeedAndDirection(SPEED_FRONT_LEFT_MOTOR_PIN, DIRECTION_FRONT_LEFT_MOTOR_PIN, left_motor_speed);
        SetMotorSpeedAndDirection(SPEED_FRONT_RIGHT_MOTOR_PIN, DIRECTION_FRONT_RIGHT_MOTOR_PIN, right_motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, left_motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, right_motor_speed);
        // Serial.println("Go_Forward() function is called.");
}

void ROBOT_GIBANJE::Go_Back(int motor_speed)
{
        // Default speed is maximum when you don't send any value to function

        SetMotorSpeedAndDirection(SPEED_FRONT_LEFT_MOTOR_PIN, DIRECTION_FRONT_LEFT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_FRONT_RIGHT_MOTOR_PIN, DIRECTION_FRONT_RIGHT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, motor_speed);
        // Serial.println("Go_Back() function is called.");
}

void ROBOT_GIBANJE::Go_Right(int motor_speed)
{
        // Default speed is maximum when you don't send any value to function

        SetMotorSpeedAndDirection(SPEED_FRONT_LEFT_MOTOR_PIN, DIRECTION_FRONT_LEFT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_FRONT_RIGHT_MOTOR_PIN, DIRECTION_FRONT_RIGHT_MOTOR_PIN, -motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, -motor_speed);
        // Serial.println("Go_Left() function is called.");
}

void ROBOT_GIBANJE::Go_Left(int motor_speed)
{
        // Default speed is maximum when you don't send any value to function

        SetMotorSpeedAndDirection(SPEED_FRONT_LEFT_MOTOR_PIN, DIRECTION_FRONT_LEFT_MOTOR_PIN, -motor_speed);
        SetMotorSpeedAndDirection(SPEED_FRONT_RIGHT_MOTOR_PIN, DIRECTION_FRONT_RIGHT_MOTOR_PIN, motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, -motor_speed);
        SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, motor_speed);
        // Serial.println("Go_Right() function is called.");
}

void ROBOT_GIBANJE::Stop_Robot()
{

        SetMotorSpeedAndDirection(SPEED_FRONT_LEFT_MOTOR_PIN, DIRECTION_FRONT_LEFT_MOTOR_PIN, 0);
        SetMotorSpeedAndDirection(SPEED_FRONT_RIGHT_MOTOR_PIN, DIRECTION_FRONT_RIGHT_MOTOR_PIN, 0);
        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, 0);
        SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, 0);
        // Serial.println("Stop_Robot() function is called.");
}

uint16_t ROBOT_GIBANJE::Read_Forward_Left_Distance() //
{
        float volts = analogRead(FORWARD1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Forward_Right_Distance() //
{
        float volts = analogRead(FORWARD2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Left_Front_Distance()
{
        float volts = analogRead(LEFT1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Left_Back_Distance()
{
        float volts = analogRead(LEFT2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Right_Front_Distance()
{
        float volts = analogRead(RIGHT1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Right_Back_Distance() //
{
        float volts = analogRead(RIGHT2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 17.5 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in centimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Forward_Left_Distance_Millimetters() //
{
        float volts = analogRead(FORWARD1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Forward_Right_Distance_Millimetters() //
{
        float volts = analogRead(FORWARD2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Left_Front_Distance_Millimetters()
{
        float volts = analogRead(LEFT1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Left_Back_Distance_Millimetters()
{
        float volts = analogRead(LEFT2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Right_Front_Distance_Millimetters()
{
        float volts = analogRead(RIGHT1_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in millimeters
        return distance;
}

uint16_t ROBOT_GIBANJE::Read_Right_Back_Distance_Millimetters() //
{
        float volts = analogRead(RIGHT2_AN_PIN) * 0.0048828125; // value from sensor * (5/1024)
        //Serial.println(volts);
        int distance = 175 * pow(volts, -0.937); // worked out from datasheet graph
        //delay(1000); // slow down serial port
        //Serial.println(distance); // print the distance in centimeters
        return distance;
}

void ROBOT_GIBANJE::Read_All_Distances_Millimetters(int delayInMicroseconds = 1000)
{
        Serial.println("LEFT --- FRONT --- RIGHT");
        Serial.print(Read_Left_Front_Distance_Millimetters());
        Serial.print("  ");
        Serial.print(Read_Left_Back_Distance_Millimetters());
        Serial.print(" : ");
        Serial.print(Read_Forward_Left_Distance_Millimetters());
        Serial.print("  ");
        Serial.print(Read_Forward_Right_Distance_Millimetters());
        Serial.print(" : ");
        Serial.print(Read_Right_Front_Distance_Millimetters());
        Serial.print("  ");
        Serial.println(Read_Right_Back_Distance_Millimetters());
        Serial.println("__________________________");
        delay(delayInMicroseconds);
}

void ROBOT_GIBANJE::Read_All_Distances(int delayInMicroseconds = 1000)
{
        Serial.println("LEFT --- FRONT --- RIGHT");
        Serial.print(Read_Left_Front_Distance());
        Serial.print("  ");
        Serial.print(Read_Left_Back_Distance());
        Serial.print(" : ");
        Serial.print(Read_Forward_Left_Distance());
        Serial.print("  ");
        Serial.print(Read_Forward_Right_Distance());
        Serial.print(" : ");
        Serial.print(Read_Right_Front_Distance());
        Serial.print("  ");
        Serial.println(Read_Right_Back_Distance());
        Serial.println("__________________________");
        delay(delayInMicroseconds);
}

void ROBOT_GIBANJE::Go_Forward_30cm(int motor_speed)
{
        // Default speed is maximum when you don't send any value to function
}

void ROBOT_GIBANJE::Go_Back_30cm(int motor_speed)
{
        // Default speed is maximum when you don't send any value to function
}

float ROBOT_GIBANJE::Read_Gyroscope_X_Axis_Orientation()
{ //Return orientation toward X axis

        sensors_event_t event;
        gyroscope.getEvent(&event);
        //Serial.println("Temporary robot orientation toward X axis is: ");
        //Serial.println(event.orientation.x);
        return event.orientation.x;
}

float ROBOT_GIBANJE::Read_Gyroscope_Z_Axis_Orientation()
{
        //Return orientation toward Z axis

        sensors_event_t event;
        gyroscope.getEvent(&event);
        //Serial.println("Temporary robot orientation toward X axis is: ");
        //Serial.println(event.orientation.x);
        return event.orientation.z * (-1);
}

void ROBOT_GIBANJE::Rotate_Robot_For_180_degrees(int motor_speed)
{
        Rotate_Left_With_Specific_Angle(45);
        Rotate_Left_With_Specific_Angle(45);
        Rotate_Left_With_Specific_Angle(45);
        Rotate_Left_With_Specific_Angle(45);
}

bool ROBOT_GIBANJE::Stopped_Is_Wall_Forward_OR_Logic()
{
        if ((Read_Forward_Left_Distance() < Check_Is_Front_Walls_Opend) || (Read_Forward_Right_Distance() < Check_Is_Front_Walls_Opend))
                return true;
        else
                return false;
}

bool ROBOT_GIBANJE::Stopped_Is_Wall_Left_OR_Logic()
{
        if ((Read_Left_Back_Distance() < Check_Is_Side_Walls_Opend) || (Read_Left_Front_Distance() < Check_Is_Side_Walls_Opend))
                return true;
        else
                return false;
}
bool ROBOT_GIBANJE::Stopped_Is_Wall_Right_OR_Logic()
{
        if ((Read_Right_Back_Distance() < Check_Is_Side_Walls_Opend) || (Read_Right_Front_Distance() < Check_Is_Side_Walls_Opend))
                return true;
        else
                return false;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool ROBOT_GIBANJE::Stopped_Is_Wall_Forward_AND_Logic()
{
        if ((Read_Forward_Left_Distance() < Check_Is_Front_Walls_Opend) || (Read_Forward_Right_Distance() < Check_Is_Front_Walls_Opend))
                return true;
        else
                return false;
}

bool ROBOT_GIBANJE::Stopped_Is_Wall_Left_AND_Logic()
{
        if ((Read_Left_Back_Distance() < Check_Is_Side_Walls_Opend) || (Read_Left_Front_Distance() < Check_Is_Side_Walls_Opend))
                return true;
        else
                return false;
}
bool ROBOT_GIBANJE::Stopped_Is_Wall_Right_AND_Logic()
{
        if ((Read_Right_Back_Distance() < Check_Is_Side_Walls_Opend) || (Read_Right_Front_Distance() < Check_Is_Side_Walls_Opend))
                return true;
        else
                return false;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool ROBOT_GIBANJE::Moveing_Is_Wall_Forward_AND_Logic()
{
        if ((Read_Forward_Left_Distance() < Optimal_Stop_Front_Distance_For_Center_Robot) && (Read_Forward_Right_Distance() < Optimal_Stop_Front_Distance_For_Center_Robot))
                return true;
        else
                return false;
}

bool ROBOT_GIBANJE::Moveing_Is_Wall_Forward_OR_Logic()
{
        if ((Read_Forward_Left_Distance() < Optimal_Stop_Front_Distance_For_Center_Robot) || (Read_Forward_Right_Distance() < Optimal_Stop_Front_Distance_For_Center_Robot))
                return true;
        else
                return false;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ROBOT_GIBANJE::Push_Box()
{
        digitalWrite(ELECTROMAGNET_PIN1, LOW);
        digitalWrite(ELECTROMAGNET_PIN2, HIGH);
        delay(2000);
        digitalWrite(ELECTROMAGNET_PIN1, LOW);
        digitalWrite(ELECTROMAGNET_PIN2, LOW);
}

void ROBOT_GIBANJE::Find_and_Align_Left_Wall()
{
        uint16_t Current_Left_Front_Distance = Read_Left_Front_Distance();
        uint16_t Current_Left_Back_Distance = Read_Left_Back_Distance();
        uint16_t Alowed_Error = 2; //This two sensors values need to be very closed because we want precise robot alignment toward left wall

        while (((Current_Left_Front_Distance - Current_Left_Back_Distance) > Alowed_Error) || ((Current_Left_Front_Distance - Current_Left_Back_Distance) < (-Alowed_Error)))
        {
                Go_Right(20);
                Current_Left_Front_Distance = Read_Left_Front_Distance();
                Current_Left_Back_Distance = Read_Left_Back_Distance();
                Serial.println("##################################################");
                Serial.print("Front...");
                Serial.println(Current_Left_Front_Distance);
                Serial.print("Back...");
                Serial.println(Current_Left_Back_Distance);
                Serial.print("Razlika...");
                Serial.println(Current_Left_Front_Distance - Current_Left_Back_Distance);
                Serial.println("We are trying to allign robot left side...");
                delay(100);
        }
        Serial.println("Robot is alligned with left side.");
        Stop_Robot();
        //delay(200);

        //First break point

        /*
############################## PSEUDO CODE ############################## 
1.Rotate
2.When two left sensors have similar distances, stop rotating
#########################################################################
*/
}

void ROBOT_GIBANJE::Center_Robot()
{
        /*
        if ((Moveing_Is_Wall_Forward() && Moveing_Is_Wall_Left()) || (Moveing_Is_Wall_Forward() && Moveing_Is_Wall_Right()))
                Serial.println("Robot front side is oriented toward closed  maze side.");

        else if ((Moveing_Is_Wall_Back() && Moveing_Is_Wall_Left()) || (Moveing_Is_Wall_Back() && Moveing_Is_Wall_Right()))
        {
                Go_180degrees();
                Serial.println("Rotating left for 180 degrees...Robot front side is oriented toward closed  maze side.");
        }

        else if ((Moveing_Is_Wall_Left() && Moveing_Is_Wall_Forward()) || (Moveing_Is_Wall_Left() || Moveing_Is_Wall_Back()))
        {
                Go_Left_90degrees();
                Serial.println("Rotating left for 90 degrees...Robot front side is oriented toward closed  maze side.");
        }

        else if ((Moveing_Is_Wall_Right() && Moveing_Is_Wall_Forward()) || (Moveing_Is_Wall_Right() || Moveing_Is_Wall_Back()))
        {
                Go_Right_90degrees();
                Serial.println("Rotating right for 90 degrees...Robot front side is oriented toward closed  maze side.");
        }
        //else Serial.println("Maybe make function for rotation of 45 degrees is else case!?");DrzacZaBateriju
        
*/
        if ((Read_Forward_Left_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)))
        {
                while ((Read_Forward_Left_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)))
                {
                        Go_Back();
                        Read_Forward_Left_Distance();
                        Read_Forward_Right_Distance();
                }
        }

        else if ((Read_Forward_Left_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)))
        {
                while ((Read_Forward_Left_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)))
                {
                        Go_Forward();
                        Read_Forward_Left_Distance();
                        Read_Forward_Right_Distance();
                }
        }

        if (Stopped_Is_Wall_Left_AND_Logic())
        {
                Rotate_Left_With_Specific_Angle(90);
        }

        else if (Stopped_Is_Wall_Right_AND_Logic())
        {
                Rotate_Right_With_Specific_Angle(90);
        }

        if ((Read_Forward_Left_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)))
        {
                while ((Read_Forward_Left_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() < (Optimal_Stop_Front_Distance_For_Center_Robot)))
                {
                        Go_Back();
                        Read_Forward_Left_Distance();
                        Read_Forward_Right_Distance();
                }
        }

        else if ((Read_Forward_Left_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)))
        {
                while ((Read_Forward_Left_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)) && (Read_Forward_Right_Distance() > (Optimal_Stop_Front_Distance_For_Center_Robot)))
                {
                        Go_Forward();
                        Read_Forward_Left_Distance();
                        Read_Forward_Right_Distance();
                }
        }

        /*
############################## PSEUDO CODE ############################## 
1.Rotate front robot side toward closed wall on which are attached one more wall (left or right one)
2.Go forward or backward and stop when needed distance is found
3.Rotate front robot side for +-90 degrees oriented toward wall founded in first step (finding left or right wall)
4.Go forward or backward and stop when needed distance is found
5.Robot is centered
#########################################################################
*/
}

void ROBOT_GIBANJE::Find_and_Rotate_To_Opend_Wall(int opendWallsDIstance = 30, int delayInMicroseconds = 1000)
{
        /*
if (( Read_Forward_Left_Distance() && Read_Forward_Middle_Distance() && Read_Forward_Right_Distance()) > Check_Walls_Distance) Serial.println("Robot front side is oriented toward opened  maze side.");

else if((Read_Back_Left_Distance() && Read_Back_Middle_Distance() && Read_Back_Right_Distance()) > Check_Walls_Distance ){
        Go_180degrees();
        Serial.println("Rotating left for 180 degrees...Robot front side is oriented toward opened  maze side.");
}

else if((Read_Left_Back_Distance() && Read_Left_Front_Distance()) > Check_Walls_Distance ){
        Go_Left_90degrees();
        Serial.println("Rotating left for 90 degrees...Robot front side is oriented toward opened  maze side.");
}

else if((Read_Right_Back_Distance() && Read_Right_Front_Distance()) > Check_Walls_Distance ){
        Go_Right_90degrees();
        Serial.println("Rotating right for 90 degrees...Robot front side is oriented toward opened  maze side.");
}

else Serial.println("Maybe make functio for rotation of 45 degrees!?");
*/

        /*    if (Moveing_Is_Wall_Opend_Forward())
                Serial.println("Robot front side is oriented toward opened  maze side.");

        else if (Moveing_Is_Wall_Opend_Back())
        {
                Go_180degrees();
                Serial.println("Rotating left for 180 degrees...Robot front side is oriented toward opened  maze side.");
        }
        */
        int Forward_Left, Forward_Right, Left_Front, Left_Back, Right_Front, Right_Back;

        Forward_Left = Read_Forward_Left_Distance();
        Forward_Right = Read_Forward_Right_Distance();
        Left_Front = Read_Left_Front_Distance();
        Left_Back = Read_Left_Back_Distance();
        Right_Front = Read_Right_Front_Distance();
        Right_Back = Read_Right_Back_Distance();

        Serial.println("LEFT --- FRONT --- RIGHT");
        Serial.print(Left_Front);
        Serial.print("  ");
        Serial.print(Left_Back);
        Serial.print(" : ");
        Serial.print(Forward_Left);
        Serial.print("  ");
        Serial.print(Forward_Right);
        Serial.print(" : ");
        Serial.print(Right_Front);
        Serial.print("  ");
        Serial.println(Right_Back);
        Serial.println("__________________________");
        delay(delayInMicroseconds);

        if ((Read_Forward_Left_Distance() > opendWallsDIstance) && (Read_Forward_Right_Distance() > opendWallsDIstance))
        {
                Serial.println("Robot front side is oriented toward opened  maze side.");
                Serial.println("---------------------------------------------------------------------------------------");
                delay(delayInMicroseconds);
        }

        else if ((Read_Left_Front_Distance() > opendWallsDIstance) && (Read_Left_Back_Distance() > opendWallsDIstance))
        {
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
                Serial.println("Rotating left for 90 degrees...Robot front side is oriented toward opened  maze side.");
                Serial.println("---------------------------------------------------------------------------------------");
                delay(delayInMicroseconds);
        }

        else if ((Read_Right_Front_Distance() > opendWallsDIstance) && (Read_Right_Back_Distance() > opendWallsDIstance))
        {
                Rotate_Right_With_Specific_Angle(45);
                Rotate_Right_With_Specific_Angle(45);
                Serial.println("Rotating right for 90 degrees...Robot front side is oriented toward opened  maze side.");
                Serial.println("---------------------------------------------------------------------------------------");
                delay(delayInMicroseconds);
        }

        else
        {
                Serial.println("Maybe make function for rotation of 45 degrees in else case!?");
                Rotate_Robot_For_180_degrees();
                Serial.println("Rotating for 180 degrees ...Robot front side is oriented toward opened  maze side.");
                Serial.println(" Find_and_Rotate_To_Opend_Wall else condition is done");
                Serial.println("---------------------------------------------------------------------------------------");
                delay(delayInMicroseconds);
        }
        //Seconde break point

        /*
############################## PSEUDO CODE ############################## 
1.Robot stays od the place and try to find opend maze side with distance sensor
2.Rotate robot toward opend side
#########################################################################
*/
}

void ROBOT_GIBANJE::Automomus_Maze_Path_Finding()
{

        if ((Read_Forward_Left_Distance() > 300) && (Read_Forward_Right_Distance() > 300))
        {
                Go_Forward_30cm();
                Serial.println("Going forward to the first wall.");
                Serial.print("Autonomus mode-Forward Left Distance:");
                Serial.println(Read_Forward_Left_Distance());
                Serial.print("Autonomus mode-Forward Right Distance:");
                Serial.println(Read_Forward_Right_Distance());
        }

        else
        {
                Go_Forward();
                Serial.println("Going forward to the first wall.");
                Serial.print("Autonomus mode-Forward Left Distance:");
                Serial.println(Read_Forward_Left_Distance());
                Serial.print("Autonomus mode-Forward Right Distance:");
                Serial.println(Read_Forward_Right_Distance());
                if (Moveing_Is_Wall_Forward_AND_Logic())
                {
                        Stop_Robot();
                        Find_and_Rotate_To_Opend_Wall();
                }
        }

        /*
############################## PSEUDO CODE ############################## 
1.Robot goes forward with 30cm if the next wall is away
2.When the wall is near to robot we go forward with smaller step than is 30cm
3.When wall is too close to front robot side we stop robot
4.Finding and rotation robot toward current opend wall  
#########################################################################
*/
}

void ROBOT_GIBANJE::Rotate_Right_With_Specific_Angle(int angle, int delayTime = 0, int motor_speed = 30) //angle ust be  values between 0 and 90 degrees
{
        int current_Orientation = Read_Gyroscope_X_Axis_Orientation();
        int16_t wanted_heading;
        Serial.print("Current Orientation: ");
        Serial.println(current_Orientation);
        delay(delayTime);

        if ((current_Orientation >= 271) && (current_Orientation <= 360))
        {
                current_Orientation = current_Orientation - 360;
                wanted_heading = current_Orientation + angle;

                if (wanted_heading > 360)
                {
                        wanted_heading = wanted_heading - 360;
                }

                Serial.println("I am in If loop.");

                Serial.print("Current Orientation: ");
                Serial.println(current_Orientation);

                Serial.print("Wanted heading: ");
                Serial.println(wanted_heading);

                delay(delayTime);

                while ((current_Orientation >= -89) && (current_Orientation < 0) && (current_Orientation < wanted_heading))
                {

                        Serial.println("I am in 1 If While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);
                        delay(delayTime);

                        Go_Right();

                        current_Orientation = Read_Gyroscope_X_Axis_Orientation() - 360;
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }

                current_Orientation = Read_Gyroscope_X_Axis_Orientation();

                while (current_Orientation < wanted_heading)
                {
                        Serial.println("I am in 2 If While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);
                        delay(delayTime);

                        Go_Right();
                        current_Orientation = Read_Gyroscope_X_Axis_Orientation();
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }
        }

        else
        {
                current_Orientation = current_Orientation;
                wanted_heading = current_Orientation + angle;

                if (wanted_heading > 360)
                {
                        wanted_heading = wanted_heading - 360;
                }

                Serial.println("I am in Else loop.");

                Serial.print("Current Orientation: ");
                Serial.println(current_Orientation);

                Serial.print("Wanted heading: ");
                Serial.println(wanted_heading);

                delay(delayTime);

                while (current_Orientation < wanted_heading)
                {
                        Serial.println("I am in Else While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);

                        delay(delayTime);

                        Go_Right();
                        current_Orientation = Read_Gyroscope_X_Axis_Orientation();
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }
        }

        Stop_Robot();
        delay(delayTime); //################################################################################
        Serial.println("Robot rotated END.");
        Serial.print("Current Orientation: ");
        Serial.println(current_Orientation);
}

void ROBOT_GIBANJE::Rotate_Left_With_Specific_Angle(int angle, int delayTime = 0, int motor_speed = 30) //angle ust be  values between 0 and 90 degrees
{

        int current_Orientation = Read_Gyroscope_X_Axis_Orientation();

        int16_t wanted_heading;
        Serial.print("Current Orientation: ");
        Serial.println(current_Orientation);
        delay(delayTime);

        if ((current_Orientation >= 0) && (current_Orientation <= 89))
        {
                current_Orientation = current_Orientation + 360;
                wanted_heading = current_Orientation - angle;

                if (wanted_heading < 0)
                {
                        wanted_heading = wanted_heading + 360;
                }

                Serial.println("I am in If loop.");

                Serial.print("Current Orientation: ");
                Serial.println(current_Orientation);

                Serial.print("Wanted heading: ");
                Serial.println(wanted_heading);
                delay(delayTime);

                while ((current_Orientation >= 360) && (current_Orientation < 449) && (current_Orientation > wanted_heading))
                {

                        Serial.println("I am in 1 If While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);
                        delay(delayTime);

                        Go_Left();

                        current_Orientation = Read_Gyroscope_X_Axis_Orientation() + 360;
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }

                current_Orientation = Read_Gyroscope_X_Axis_Orientation();

                while (current_Orientation > wanted_heading)
                {
                        Serial.println("I am in 2 If While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);
                        delay(delayTime);

                        Go_Left();
                        current_Orientation = Read_Gyroscope_X_Axis_Orientation();
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }
        }

        else
        {
                current_Orientation = current_Orientation;
                wanted_heading = current_Orientation - angle;

                if (wanted_heading < 0)
                {
                        wanted_heading = wanted_heading + 360;
                }

                Serial.println("I am in Else loop.");

                Serial.print("Current Orientation: ");
                Serial.println(current_Orientation);

                Serial.print("Wanted heading: ");
                Serial.println(wanted_heading);
                delay(delayTime);

                while (current_Orientation > wanted_heading)
                {
                        Serial.println("I am in Else While loop.");

                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);

                        Serial.print("Wanted heading: ");
                        Serial.println(wanted_heading);
                        delay(delayTime);

                        Go_Left();
                        current_Orientation = Read_Gyroscope_X_Axis_Orientation();
                        Serial.println("Robot rotated.");
                        Serial.print("Current Orientation: ");
                        Serial.println(current_Orientation);
                }
        }

        Stop_Robot();
        delay(delayTime); //################################################################################
        Serial.println("Robot rotated END.");
        Serial.print("Current Orientation: ");
        Serial.println(current_Orientation);
}

int ROBOT_GIBANJE::Align_To_Left_Wall(int Alowed_Error = 1, int delayTime = 0)
{

        int Left_Front, Left_Back;

        Left_Front = Read_Left_Front_Distance_Millimetters();
        Left_Back = Read_Left_Back_Distance_Millimetters();

        Serial.println("No Loop");
        Serial.println("FRONT_L --- BACK_L");
        Serial.print(Left_Front);
        Serial.print(" : ");
        Serial.println(Left_Back);

        float WallFollowingError = Left_Front - Left_Back;
        Serial.println("Error");
        Serial.println(WallFollowingError);
        Serial.println("--------------------------------------");

        //delay(delayTime);

        if (((WallFollowingError * WallFollowingError) > Alowed_Error * Alowed_Error))
        {

                Serial.println("I am in Error While loop.");
                Serial.println("##########################");

                while (WallFollowingError > Alowed_Error)
                {

                        Left_Front = Read_Left_Front_Distance_Millimetters();
                        Left_Back = Read_Left_Back_Distance_Millimetters();
                        WallFollowingError = Left_Front - Left_Back;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Left_Front);
                        Serial.print(" : ");
                        Serial.println(Left_Back);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Left.");
                        Serial.println("--------------------------------------");
                        Go_Left();
                        delay(30);
                }

                while (WallFollowingError < -Alowed_Error)
                {

                        Left_Front = Read_Left_Front_Distance_Millimetters();
                        Left_Back = Read_Left_Back_Distance_Millimetters();
                        WallFollowingError = Left_Front - Left_Back;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Left_Front);
                        Serial.print(" : ");
                        Serial.println(Left_Back);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Right.");
                        Serial.println("--------------------------------------");
                        Go_Right();
                        delay(30);
                }

                Serial.println("Robot aligned.");
                Stop_Robot();
                //delay(delayTime);
        }

        int16_t initial_heading = Read_Gyroscope_X_Axis_Orientation();
        return initial_heading;
}

int ROBOT_GIBANJE::Align_To_Right_Wall(int Alowed_Error = 1, int delayTime = 0)
{

        int Right_Front, Right_Back;

        Right_Front = Read_Right_Front_Distance_Millimetters();
        Right_Back = Read_Right_Back_Distance_Millimetters();

        Serial.println("No Loop");
        Serial.println("FRONT_L --- BACK_L");
        Serial.print(Right_Front);
        Serial.print(" : ");
        Serial.println(Right_Back);

        float WallFollowingError = Right_Front - Right_Back;
        Serial.println("Error");
        Serial.println(WallFollowingError);
        Serial.println("--------------------------------------");

        //delay(delayTime);

        if (((WallFollowingError * WallFollowingError) > Alowed_Error * Alowed_Error))
        {

                Serial.println("I am in Error While loop.");
                Serial.println("##########################");

                while (WallFollowingError > Alowed_Error)
                {

                        Right_Front = Read_Right_Front_Distance_Millimetters();
                        Right_Back = Read_Right_Back_Distance_Millimetters();
                        WallFollowingError = Right_Front - Right_Back;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Right_Front);
                        Serial.print(" : ");
                        Serial.println(Right_Back);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Right.");
                        Serial.println("--------------------------------------");
                        Go_Right();
                        delay(30);
                }

                while (WallFollowingError < -Alowed_Error)
                {

                        Right_Front = Read_Right_Front_Distance_Millimetters();
                        Right_Back = Read_Right_Back_Distance_Millimetters();
                        WallFollowingError = Right_Front - Right_Back;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Right_Front);
                        Serial.print(" : ");
                        Serial.println(Right_Back);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Left.");
                        Serial.println("--------------------------------------");
                        Go_Left();
                        delay(30);
                }

                Serial.println("Robot aligned.");
                Stop_Robot();
                //delay(delayTime);
        }

        int16_t initial_heading = Read_Gyroscope_X_Axis_Orientation();
        return initial_heading;
}
int ROBOT_GIBANJE::Align_To_Front_Wall(int Alowed_Error = 1, int delayTime = 0)
{

        int Forward_Left, Forward_Right;

        Forward_Left = Read_Forward_Left_Distance_Millimetters();
        Forward_Right = Read_Forward_Right_Distance_Millimetters();

        Serial.println("No Loop");
        Serial.println("FRONT_L --- BACK_L");
        Serial.print(Forward_Left);
        Serial.print(" : ");
        Serial.println(Forward_Right);

        float WallFollowingError = Forward_Left - Forward_Right;
        Serial.println("Error");
        Serial.println(WallFollowingError);
        Serial.println("--------------------------------------");

        //delay(delayTime);

        if (((WallFollowingError * WallFollowingError) > Alowed_Error * Alowed_Error))
        {

                Serial.println("I am in Error While loop.");
                Serial.println("##########################");

                while (WallFollowingError > Alowed_Error)
                {

                        Forward_Left = Read_Forward_Left_Distance_Millimetters();
                        Forward_Right = Read_Forward_Right_Distance_Millimetters();
                        WallFollowingError = Forward_Left - Forward_Right;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Forward_Left);
                        Serial.print(" : ");
                        Serial.println(Forward_Right);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Right.");
                        Serial.println("--------------------------------------");
                        Go_Right();
                        delay(30);
                }

                while (WallFollowingError < -Alowed_Error)
                {

                        Forward_Left = Read_Forward_Left_Distance_Millimetters();
                        Forward_Right = Read_Forward_Right_Distance_Millimetters();
                        WallFollowingError = Forward_Left - Forward_Right;
                        Serial.println("FRONT_L --- BACK_L");
                        Serial.print(Forward_Left);
                        Serial.print(" : ");
                        Serial.println(Forward_Right);
                        Serial.println("Error: ");
                        Serial.println(WallFollowingError);
                        Serial.println("Going Left.");
                        Serial.println("--------------------------------------");
                        Go_Left();
                        delay(30);
                }

                Serial.println("Robot aligned.");
                Stop_Robot();
                //delay(delayTime);
        }

        int16_t initial_heading = Read_Gyroscope_X_Axis_Orientation();
        return initial_heading;
}

void ROBOT_GIBANJE::Stay_Away_From_Left_Wall(int wanted_running_function_time = 500)
{
        int start_time, end_time, running_function_time_interval;
        int Left_Front = Read_Left_Front_Distance();
        Serial.println("Left_Front");
        Serial.println(Left_Front);
        Serial.println("--------------");
        Go_Forward();

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Left_Front <= 12) && (running_function_time_interval < wanted_running_function_time))
        {
                Go_Forward(32 - Left_Front, 18);

                Left_Front = Read_Left_Front_Distance();
                Serial.println("Left_Front");
                Serial.println(Left_Front);
                Serial.println("--------------");

                end_time = millis();
        }
}

void ROBOT_GIBANJE::Stay_Away_From_Right_Wall(int wanted_running_function_time = 500)
{
        int start_time, end_time, running_function_time_interval;
        int Right_Front = Read_Right_Front_Distance();
        Serial.println("Right_Front");
        Serial.println(Right_Front);
        Serial.println("--------------");
        Go_Forward();

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Right_Front <= 12) && (running_function_time_interval < wanted_running_function_time))
        {
                Go_Forward(18, 32 - Right_Front);

                Right_Front = Read_Right_Front_Distance();
                Serial.println("Right_Front");
                Serial.println(Right_Front);
                Serial.println("--------------");

                end_time = millis();
        }
}

void ROBOT_GIBANJE::Keep_Optimal_Distance_With_Left_Wall(int Ideal_Left_Distance = 13)
{

        int Left_Front = Read_Left_Front_Distance();
        Serial.println("Left_Front");
        Serial.println(Left_Front);
        Serial.println("--------------");
        Go_Forward();

        while ((Left_Front >= 14) && (Left_Front <= 25))
        {
                Go_Forward(18, 20 + (Left_Front - Ideal_Left_Distance));

                Left_Front = Read_Left_Front_Distance();
                Serial.println("Left_Front");
                Serial.println(Left_Front);
                Serial.println("--------------");
        }
}

void ROBOT_GIBANJE::Keep_Optimal_Distance_With_Right_Wall(int Ideal_Right_Distance = 13)
{

        int Right_Front = Read_Right_Front_Distance();
        Serial.println("Right_Front");
        Serial.println(Right_Front);
        Serial.println("--------------");
        Go_Forward();

        while ((Right_Front >= 14) && (Right_Front <= 25))
        {
                Go_Forward(20 + (Right_Front - Ideal_Right_Distance), 18);

                Right_Front = Read_Right_Front_Distance();
                Serial.println("Right_Front");
                Serial.println(Right_Front);
                Serial.println("--------------");
        }
}

void ROBOT_GIBANJE::Go_Forward_Follow_Gyroscope_And_Stop_In_Front_Of_Wall_P_Regulator(int Orientation_Tolerance = 1, int delayTime = 0, int LeftandRightSpeed = 20)
{
        int Current_Orientation;

        Setpoint1 = Read_Gyroscope_X_Axis_Orientation();

        Serial.println("Decided orientation: ");
        Serial.println(Setpoint1);
        Serial.println("#################################################");
        Serial.println(" ");

        int Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
        int Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana

        int Critical_Left = Read_Left_Front_Distance();   //Snezor lijeva strana
        int Critical_Right = Read_Right_Front_Distance(); //Snezor desna strana

        delay(delayTime);

        while ((Fordward_Left > Optimal_Stop_Front_Distance_For_Center_Robot) && (Fordward_Right > Optimal_Stop_Front_Distance_For_Center_Robot))
        {

                while ((Critical_Left > 100) && (Critical_Right > 100))
                {

                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                        Serial.println(" ");
                        Serial.println("I 'am in first while loop.");
                        Serial.println("Current orientation 1st time: ");
                        Serial.println(Current_Orientation);
                        Serial.println(" ");
                        delay(delayTime);

                        if ((Setpoint1 >= 0) && (Setpoint1 <= 89))
                        {
                                int Setpoint1_Temp = Setpoint1 + 360;

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in IF condition: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF condition: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                                {
                                        Go_Left(LeftandRightSpeed);

                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                        {

                                                Current_Orientation = Current_Orientation + 360;
                                        }
                                        else
                                        {
                                                Current_Orientation = Current_Orientation;
                                        }

                                        Serial.println("Current orientation in IF 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in IF 1st WHILE LOOP: ");
                                        Serial.println(Setpoint1_Temp);
                                        Serial.println("Current EROR in IF 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1_Temp);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana

                                while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                                {
                                        Go_Right(LeftandRightSpeed);

                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                        {

                                                Current_Orientation = Current_Orientation + 360;
                                        }
                                        else
                                        {
                                                Current_Orientation = Current_Orientation;
                                        }

                                        Serial.println("Current orientation in IF 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in IF 2nd WHILE LOOP: ");
                                        Serial.println(Setpoint1_Temp);
                                        Serial.println("Current EROR in IF 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1_Temp);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana
                        }

                        else if ((Setpoint1 >= 271) && (Setpoint1 <= 360))
                        {
                                int Setpoint1_Temp = Setpoint1 - 360;
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {

                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF condition: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF condition: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                                {
                                        Go_Left(LeftandRightSpeed);
                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                        {

                                                Current_Orientation = Current_Orientation - 360;
                                        }
                                        else
                                        {
                                                Current_Orientation = Current_Orientation;
                                        }

                                        Serial.println("Current orientation in ELSE IF 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in ELSE IF 1st WHILE LOOP: ");
                                        Serial.println(Setpoint1_Temp);
                                        Serial.println("Current EROR in ELSE IF 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1_Temp);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana

                                while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                                {
                                        Go_Right(LeftandRightSpeed);
                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                        {

                                                Current_Orientation = Current_Orientation - 360;
                                        }
                                        else
                                        {
                                                Current_Orientation = Current_Orientation;
                                        }

                                        Serial.println("Current orientation in ELSE IF 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in ELSE IF 2nd WHILE LOOP: ");
                                        Serial.println(Setpoint1_Temp);
                                        Serial.println("Current EROR in ELSE IF 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1_Temp);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana
                        }

                        else
                        {
                                while ((Current_Orientation - Setpoint1) > Orientation_Tolerance)
                                {
                                        Go_Left(LeftandRightSpeed);

                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        Serial.println("Current orientation in ELSE 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in ELSE 1st WHILE LOOP: ");
                                        Serial.println(Setpoint1);
                                        Serial.println("Current EROR in ELSE 1st WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");
                                delay(500);
                                Stop_Robot();

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana

                                while ((Current_Orientation - Setpoint1) < -Orientation_Tolerance)
                                {
                                        Go_Right(LeftandRightSpeed);

                                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                        Serial.println("Current orientation in ELSE 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation);
                                        Serial.println("Decided orientation in ELSE 2nd WHILE LOOP: ");
                                        Serial.println(Setpoint1);
                                        Serial.println("Current EROR in ELSE 2nd WHILE LOOP: ");
                                        Serial.println(Current_Orientation - Setpoint1);
                                        Serial.println(" ");
                                        delay(delayTime);
                                }

                                Go_Forward();
                                Serial.println("Fobot follow gyroscope.");
                                Serial.println(" ");
                                delay(500);
                                Stop_Robot();

                                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
                                Critical_Left = Read_Left_Front_Distance();     //Snezor lijeva strana
                                Critical_Right = Read_Right_Front_Distance();   //Snezor desna strana
                        }
                }

                if ((Critical_Left < 100))
                {
                        Rotate_Right_With_Specific_Angle(5);
                }
                else if ((Critical_Right < 100))
                {
                        Rotate_Left_With_Specific_Angle(5);
                }

                Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
                Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana

                Critical_Left = Read_Left_Front_Distance();   //Snezor lijeva strana
                Critical_Right = Read_Right_Front_Distance(); //Snezor desna strana
        }

        Serial.println(" ");
        Serial.println("I am OUT MAIN WHILE LOOP");
        Serial.println(" ");

        Stop_Robot();

        Current_Orientation = Read_Gyroscope_X_Axis_Orientation();

        Fordward_Left = Read_Forward_Left_Distance();   // Senzori prednja strana
        Fordward_Right = Read_Forward_Right_Distance(); // Senzori prednja strana
}

// Function to read Red Pulse Widths
int ROBOT_GIBANJE::getRedPW()
{

        // Set sensor to read Red only
        digitalWrite(S2, LOW);
        digitalWrite(S3, LOW);
        // Define integer to represent Pulse Width
        int PW;
        // Read the output Pulse Width
        PW = pulseIn(sensorOut, LOW);
        // Return the value
        return PW;
}

// Function to read Green Pulse Widths
int ROBOT_GIBANJE::getGreenPW()
{

        // Set sensor to read Green only
        digitalWrite(S2, HIGH);
        digitalWrite(S3, HIGH);
        // Define integer to represent Pulse Width
        int PW;
        // Read the output Pulse Width
        PW = pulseIn(sensorOut, LOW);
        // Return the value
        return PW;
}

// Function to read Blue Pulse Widths
int ROBOT_GIBANJE::getBluePW()
{

        // Set sensor to read Blue only
        digitalWrite(S2, LOW);
        digitalWrite(S3, HIGH);
        // Define integer to represent Pulse Width
        int PW;
        // Read the output Pulse Width
        PW = pulseIn(sensorOut, LOW);
        // Return the value
        return PW;
}

int ROBOT_GIBANJE::Search_for_Black_or_Grey_tiles()
{

        // Read Red value
        redPW = getRedPW();
        // Map to value from 0-255
        redValue = map(redPW, redMin, redMax, 1000, 0);
        // Delay to stabilize sensor
        delay(50);

        // Read Green value
        greenPW = getGreenPW();
        // Map to value from 0-255
        greenValue = map(greenPW, greenMin, greenMax, 1000, 0);
        // Delay to stabilize sensor
        delay(50);

        // Read Blue value
        bluePW = getBluePW();
        // Map to value from 0-255
        blueValue = map(bluePW, blueMin, blueMax, 1000, 0);
        // Delay to stabilize sensor
        delay(50);

        // Print output to Serial Monitor
        Serial.print("Red = ");
        Serial.print(redValue);
        Serial.print(" - Green = ");
        Serial.print(greenValue);
        Serial.print(" - Blue = ");
        Serial.println(blueValue);

        /*
        Old Calibrated combination

        if ((redValue<163)&&(greenValue<76)&&(blueValue<213)){

        Serial.println("Black Tile");
        Go_Back();
        
        }
        */
        bool black_tile_is_founded = false;

        if ((redValue < 225) && (greenValue < 225) && (blueValue < 225))
        {

                Serial.println("Black Tile  ######################################################################33");
                Stop_Robot();
                black_tile_is_founded = true;
        }

        return black_tile_is_founded;

        //  if ((redValue>932)&&(redValue<1000)&&(greenValue>974)&&(greenValue<1000)&&(blueValue>969)&&(blueValue<1000)){
        //    Serial.println("White Tile");
        //    }
}

void ROBOT_GIBANJE::Go_Forward_And_Follow_Gyroscope_P_Regulator(int Setpoint1, int Orientation_Tolerance = 1, int delayTime = 0)
{
        int left_and_right_motor_speed = 20;

        Serial.println("Decided orientation: ");
        Serial.println(Setpoint1);
        Serial.println("#################################################");
        Serial.println(" ");
        delay(delayTime);

        int time_1 = millis();
        int time_2 = millis();

        //Prevous while condition
        //(time_2 - time_1) < 4000
        //(Read_Forward_Left_Distance() > 100) && (Read_Forward_Right_Distance() > 100)

        while (true) //condition - probably encoder distance
        {

                Serial.println(time_2 - time_1);
                time_2 = millis();

                /*   Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                Serial.println(" ");
                Serial.println("I 'am in first while loop.");
                Serial.println("Current orientation 1st time: ");
                Serial.println(Current_Orientation);
                Serial.println(" ");
                delay(delayTime);
                */

                /* code */
                //Potencijalni problem
                int Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                if ((Setpoint1 >= 0) && (Setpoint1 <= 89))
                {

                        int Setpoint1_Temp = Setpoint1 + 360;
                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                        Serial.println("Current orientation in IF condition: ");
                        Serial.println(Current_Orientation);

                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                        {

                                Current_Orientation = Current_Orientation + 360;
                        }
                        else
                        {
                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Setpoint1 orientation in IF condition: ");
                        Serial.println(Setpoint1);
                        Serial.println("Decided orientation in IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println("Error is: ");
                        Serial.println(Current_Orientation - Setpoint1_Temp);
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                                Serial.println("Current orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Decided orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                                Serial.println("Current orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                // Current orientation je 499, kako?

                                Serial.println("Decided orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                }

                else if ((Setpoint1 >= 271) && (Setpoint1 <= 360))
                {
                        int Setpoint1_Temp = Setpoint1 - 360;
                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                        Serial.println("Current orientation in ELSE IF condition: ");
                        Serial.println(Current_Orientation);

                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                        {

                                Current_Orientation = Current_Orientation - 360;
                        }
                        else
                        {

                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Decided orientation in ELSE IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println(" ");
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                                Serial.println("Current orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Decided orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }
                                Serial.println("Decided orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                }

                else
                {
                        while ((Current_Orientation - Setpoint1) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        while ((Current_Orientation - Setpoint1) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }

                        Go_Forward();
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                }
        }
}

int ROBOT_GIBANJE::Read_Right_Encoder(int right_motor_speed = 20)
{
        //SetMotorSpeedAndDirection(SPEED_BACK_RIGHT_MOTOR_PIN, DIRECTION_BACK_RIGHT_MOTOR_PIN, right_motor_speed);

        int counter;
        int The_Last_state_left_encoder = 1;
        int aState;
        float distance = 0;

        //Serial.print("While");

        aState = digitalRead(ENCODER_RIGHT_A_OUT); // Reads the "current" state of the outputA

        // If the previous and the current state of the outputA are different, that means a Pulse has occured
        if (aState != The_Last_state_left_encoder)
        {

                // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
                if (digitalRead(ENCODER_RIGHT_B_OUT) != aState)
                {
                        counter--;
                }
                else
                {
                        counter++;
                }
                Serial.print("Position: ");
                Serial.println(counter);
        }

        The_Last_state_left_encoder = aState; // Updates the previous state of the outputA with the current state

        return true;
}

int ROBOT_GIBANJE::Read_Left_Encoder(int left_motor_speed = 20)
{

        SetMotorSpeedAndDirection(SPEED_BACK_LEFT_MOTOR_PIN, DIRECTION_BACK_LEFT_MOTOR_PIN, left_motor_speed);

        int counter;
        int The_Last_state_left_encoder = 1;
        int aState;

        while (true)
        {
                //Serial.print("While");

                aState = digitalRead(ENCODER_LEFT_A_OUT); // Reads the "current" state of the outputA

                // If the previous and the current state of the outputA are different, that means a Pulse has occured
                if (aState != The_Last_state_left_encoder)
                {

                        // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
                        if (digitalRead(ENCODER_LEFT_B_OUT) != aState)
                        {
                                counter++;
                        }
                        else
                        {
                                counter--;
                        }
                        Serial.print("Position: ");
                        Serial.println(counter);
                }

                The_Last_state_left_encoder = aState; // Updates the previous state of the outputA with the current state
        }
}

int ROBOT_GIBANJE::Optimize_speed_with_Z_Orientation(int Z_Orientation_Tolerance_First_Degree = 8, int Z_Orientation_Tolerance_Second_Degree = 15)
{
        int left_and_right_motor_speed;

        Serial.println(" ");
        Serial.println("OPTIMIZE SPEED WITH Z-ORIENTATION P-REGULATOR #########################################################");
        Serial.println(" ");

        int Z_Orientation = Read_Gyroscope_Z_Axis_Orientation() + 7;

        Serial.print("Z orientation: ");
        Serial.println(Z_Orientation);
        Serial.println("________________");

        if (Z_Orientation > Z_Orientation_Tolerance_Second_Degree)
        {

                left_and_right_motor_speed = 20 + (Z_Orientation);
        }

        else if ((Z_Orientation > Z_Orientation_Tolerance_First_Degree) && (Z_Orientation < Z_Orientation_Tolerance_Second_Degree))
        {

                left_and_right_motor_speed = 20 + 5;
        }

        else
        {
                left_and_right_motor_speed = 20;
        }

        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
        delay(100);
}

void ROBOT_GIBANJE::Read_Temperature_Left_Sensor()
{

        int outputState = analogRead(LEFT_THERMAL_CAM_OUT_PIN);

        if (outputState > 490)
        {

                Serial.print("Thermal cam value: ");
                Serial.print(outputState);
                Serial.println("TFND");
                //Stop_Robot();
        }

        //return map(analogRead(THERMAL_OUT_PIN), 0, 52851, -20, 100); Maybe correct calibration value
}
void ROBOT_GIBANJE::Read_Temperature_Right_Sensor()
{

        int outputState = analogRead(RIGHT_THERMAL_CAM_OUT_PIN);

        if (outputState > 490)
        {

                Serial.print("Thermal cam value: ");
                Serial.print(outputState);
                Serial.println("TFND");
                //Stop_Robot();
        }

        //return map(analogRead(THERMAL_OUT_PIN), 0, 52851, -20, 100); Maybe correct calibration value
}

void ROBOT_GIBANJE::Listen_Serial_Port_Optimized_For_Autonomus_Loop()
{
        if (Serial.available() > 0)
        {
                String data = Serial.readStringUntil('\n');

                if (data.substring(0) == "HFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                if (data.substring(0) == "SFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                if (data.substring(0) == "UFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                if (data.substring(0) == "STOP!")
                {
                        bool StopRobot = true;
                        while (StopRobot == true)
                        {
                                Stop_Robot();
                                delay(1000);
                        }
                }
        }
}

void ROBOT_GIBANJE::Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(int Left_Front_Distance, int Forward_Left_distance, int Forward_Right_distance, boolean founded_black_or_gray_tiles, int left_and_right_motor_speed, int Go_Forward_Delay = 100, int wanted_running_function_time = 600)
{
        int start_time, end_time, running_function_time_interval;

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Left_Front_Distance <= 12) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false) && (running_function_time_interval < wanted_running_function_time))
        {
                Serial.println(" ");
                Serial.println("GO RIGHT - Too closed to Leftt wall. STAY AWAY P-REGULATOR #########################################################");
                Serial.println(" ");

                Listen_Serial_Port_Optimized_For_Autonomus_Loop();

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();

                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                Left_Front_Distance = Read_Left_Back_Distance();
                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                Serial.println("Left Front distance: ");
                Serial.println(Left_Front_Distance);

                //Correction because we need edge distance sensor with 45 degree orinetation
                Left_Front_Distance = Left_Front_Distance - 2;

                Go_Forward(32 - Left_Front_Distance, 17);
                delay(Go_Forward_Delay);

                end_time = millis();
                running_function_time_interval = end_time - start_time;
                Serial.print("Elapsed function time: ");
                Serial.println(running_function_time_interval);
        }

        Serial.println("____________________________________");
}

void ROBOT_GIBANJE::Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(int Right_Front_Distance, int Forward_Left_distance, int Forward_Right_distance, boolean founded_black_or_gray_tiles, int left_and_right_motor_speed, int Go_Forward_Delay = 100, int wanted_running_function_time = 600)
{
        int start_time, end_time, running_function_time_interval;

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Right_Front_Distance <= 12) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false) && (running_function_time_interval < wanted_running_function_time))
        {
                Serial.println(" ");
                Serial.println("GO LEFT - Too closed to Right wall. STAY AWAY P-REGULATOR  #########################################################");
                Serial.println(" ");

                Listen_Serial_Port_Optimized_For_Autonomus_Loop();

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();

                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                Right_Front_Distance = Read_Right_Front_Distance();
                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                Serial.println("Right Front distance: ");
                Serial.println(Right_Front_Distance);

                //Correction because we need edge distance sensor with 45 degree orinetation
                Right_Front_Distance = Right_Front_Distance - 2;

                Go_Forward(17, 32 - Right_Front_Distance);
                delay(Go_Forward_Delay);

                end_time = millis();
                running_function_time_interval = end_time - start_time;
                Serial.print("Elapsed function time: ");
                Serial.println(running_function_time_interval);
        }

        Serial.println("____________________________________");
}

void ROBOT_GIBANJE::Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(int Left_Front_Distance, int Forward_Left_distance, int Forward_Right_distance, boolean founded_black_or_gray_tiles, int left_and_right_motor_speed, int Go_Forward_Delay = 100, int Ideal_Left_Distance = 13, int wanted_running_function_time = 600)
{
        int start_time, end_time, running_function_time_interval;

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Left_Front_Distance >= 14) && (Left_Front_Distance <= 25) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false) && (running_function_time_interval < wanted_running_function_time))
        {
                Serial.println(" ");
                Serial.println("Keep optimal distance with LEFT wall. KEEP OPTIMAL DISTANCE P-REGULATOR #########################################################");
                Serial.println(" ");
                Serial.println("Left_Front_Distance");
                Serial.println(Left_Front_Distance);
                Serial.println("--------------");

                Listen_Serial_Port_Optimized_For_Autonomus_Loop();

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();

                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                Go_Forward(left_and_right_motor_speed - 3, left_and_right_motor_speed + (Left_Front_Distance - Ideal_Left_Distance));
                delay(Go_Forward_Delay);

                Left_Front_Distance = Read_Left_Front_Distance();
                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                end_time = millis();
                running_function_time_interval = end_time - start_time;
                Serial.print("Elapsed function time: ");
                Serial.println(running_function_time_interval);
        }
        Serial.println("____________________________________");
}

void ROBOT_GIBANJE::Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(int Right_Front_Distance, int Forward_Left_distance, int Forward_Right_distance, boolean founded_black_or_gray_tiles, int left_and_right_motor_speed, int Go_Forward_Delay = 100, int Ideal_Right_Distance = 13, int wanted_running_function_time = 600)
{
        int start_time, end_time, running_function_time_interval;

        start_time = millis();
        end_time = millis();

        running_function_time_interval = end_time - start_time;

        while ((Right_Front_Distance >= 14) && (Right_Front_Distance <= 25) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false) && (running_function_time_interval < wanted_running_function_time))
        {
                Serial.println(" ");
                Serial.println("Keep optimal distance with RIGHT wall. KEEP OPTIMAL DISTANCE P-REGULATOR #########################################################");
                Serial.println(" ");
                Serial.println("Right_Front_Distance");
                Serial.println(Right_Front_Distance);
                Serial.println("--------------");

                Listen_Serial_Port_Optimized_For_Autonomus_Loop();

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();

                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                Go_Forward(left_and_right_motor_speed + (Right_Front_Distance - Ideal_Right_Distance), left_and_right_motor_speed - 3);
                delay(Go_Forward_Delay);

                Right_Front_Distance = Read_Right_Front_Distance();
                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                end_time = millis();
                running_function_time_interval = end_time - start_time;
                Serial.print("Elapsed function time: ");
                Serial.println(running_function_time_interval);
        }
        Serial.println("____________________________________");
}

int ROBOT_GIBANJE::Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop(int left_and_right_motor_speed = 20, int Z_Orientation_Tolerance_First_Degree = 8, int Z_Orientation_Tolerance_Second_Degree = 15)
{
        Serial.println(" ");
        Serial.println("OPTIMIZE SPEED WITH Z-ORIENTATION P-REGULATOR");
        Serial.println(" ");

        int Z_Orientation = Read_Gyroscope_Z_Axis_Orientation() + 7;

        Serial.print("Z orientation: ");
        Serial.println(Z_Orientation);
        Serial.println("________________");

        if (Z_Orientation > Z_Orientation_Tolerance_Second_Degree)
        {

                left_and_right_motor_speed = 20 + (Z_Orientation);
        }

        else if ((Z_Orientation > Z_Orientation_Tolerance_First_Degree) && (Z_Orientation < Z_Orientation_Tolerance_Second_Degree))
        {

                left_and_right_motor_speed = 20 + 5;
        }

        else
        {
                left_and_right_motor_speed = 20;
        }

        return left_and_right_motor_speed;
}

//######################################################################################################
//#####################################    MAIN ROBOT FUNCTION    ######################################
//######################################################################################################

void ROBOT_GIBANJE::Go_Autonomus_Basic_Version(int Orientation_Tolerance = 1, int delayTime = 0)
{
        //added PID Gyorscope controller
        //added side wall P regulaor avoidance
        //added speed optimization depending gyroscope z orientation
        //added Serial communication with Raspberry

        // Define left and right motor speen when robot goes forward
        int left_and_right_motor_speed = 20;
        // Define variable for read orientation in real time
        int Current_Orientation;
        //Check is something arrived from Rapberry via serial communication
        if (Serial.available() > 0)
        {
                //Define variable for read string to the new line sign
                String data = Serial.readStringUntil('\n');

                //Check is H-character is recognised
                if (data.substring(0) == "HFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is S-character is recognised
                if (data.substring(0) == "SFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is S-character is recognised
                if (data.substring(0) == "UFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is main program on Raspberry Pi ended
                if (data.substring(0) == "STOP!")
                {
                        bool StopRobot = true;
                        while (StopRobot == true)
                        {
                                Stop_Robot();
                                delay(1000);
                        }
                }
        }
        // Define variable for floor tiles recognition (for now only black color), check code of Search_for_Black_or_Grey_tiles()
        boolean founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
        //Increase default motor speed if robot detect tilt up tile or small bumps, check code of Optimize_speed_with_Z_Orientation()
        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
        //Check is Temperature victim founded
        Read_Temperature_Left_Sensor();
        //Decide orientation which robot will follow
        Setpoint1 = Read_Gyroscope_X_Axis_Orientation();
        Serial.println(" ");
        Serial.println("#################################################");
        Serial.println("Decided orientation: ");
        Serial.println(Setpoint1);
        Serial.println("Maybe the wall is in the front of robot.");
        Serial.println("#################################################");
        Serial.println(" ");
        //Delay time slows speed serial print functions, and they became readible for humans
        delay(delayTime);
        //Multitasking variables used for testing a lot of situations
        int time_1 = millis();
        int time_2 = millis();
        //Define variables and read distance sensors
        int Forward_Left_distance = Read_Forward_Left_Distance();
        int Forward_Right_distance = Read_Forward_Right_Distance();

        int Left_Front_Distance = Read_Left_Front_Distance();
        int Left_Back_Distance = Read_Left_Back_Distance();

        int Right_Front_Distance = Read_Right_Front_Distance();
        int Right_Back_Distance = Read_Right_Back_Distance();

        //Main loop of program

        //Prevous while condition
        //(time_2 - time_1) < 40000
        //(Forward_Left_distance > 300) && (Forward_Right_distance > 300)
        while ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false)) //condition - probably encoder distance
        {
                if (Serial.available() > 0)
                {

                        String data = Serial.readStringUntil('\n');

                        if (data.substring(0) == "HFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "SFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "UFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "STOP!")
                        {
                                bool StopRobot = true;
                                while (StopRobot == true)
                                {
                                        Stop_Robot();
                                        delay(1000);
                                }
                        }
                }

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                delay(100);
                Read_Temperature_Left_Sensor();

                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                Left_Front_Distance = Read_Left_Front_Distance();
                Left_Back_Distance = Read_Left_Back_Distance();

                Right_Front_Distance = Read_Right_Front_Distance();
                Right_Back_Distance = Read_Right_Back_Distance();

                //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zidaa
                while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ");
                        Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                        delay(100);
                        Left_Front_Distance = Read_Left_Back_Distance();

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();
                }
                //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ");
                        Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                        delay(100);
                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();
                }

                if (Serial.available() > 0)
                {

                        String data = Serial.readStringUntil('\n');

                        if (data.substring(0) == "HFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "SFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "UFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "STOP!")
                        {
                                bool StopRobot = true;
                                while (StopRobot == true)
                                {
                                        Stop_Robot();
                                        delay(1000);
                                }
                        }
                }
                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                Read_Temperature_Left_Sensor();

                Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                //Dio za provijeru koliko se robot zadržava u prethodnoj petlji
                Serial.println(time_2 - time_1);
                time_2 = millis();
                //Provjera trenutne orijentacije robota u odnosu na x-os naznačenu na žiroskopu
                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                //Provjera u kojem dijelu glavne petlje se nalazimo i ispis potrebnih uvijeta
                Serial.println(" ");
                Serial.println("I 'am in first while loop.");
                Serial.println("Current orientation 1st time: ");
                Serial.println(Current_Orientation);
                Serial.println(" ");
                delay(delayTime);

                //Interpolacije žiroskopa, objašnjeno u diplomskom radu
                if ((Setpoint1 >= 0) && (Setpoint1 <= 89) && (founded_black_or_gray_tiles == false))
                {
                        int Setpoint1_Temp = Setpoint1 + 360;

                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                        {

                                Current_Orientation = Current_Orientation + 360;
                        }
                        else
                        {
                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println("Error is: ");
                        Serial.println(Current_Orientation - Setpoint1_Temp);
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                // Željena orijentacija se nalazi lijevo od trenutne orijentacije stoga se robot pomoću P-regulatora rotora u lijevo
                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();

                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }
                                // Current orientation je 499, kako?
                                Serial.println("Current orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();

                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else if ((Setpoint1 >= 271) && (Setpoint1 <= 360) && (founded_black_or_gray_tiles == false))
                {
                        int Setpoint1_Temp = Setpoint1 - 360;
                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                        {

                                Current_Orientation = Current_Orientation - 360;
                        }
                        else
                        {

                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in ELSE IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in ELSE IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println(" ");
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();

                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else
                {
                        while (((Current_Orientation - Setpoint1) > Orientation_Tolerance) && (founded_black_or_gray_tiles == false))
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();

                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        while ((Left_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed + 10, left_and_right_motor_speed - 10);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                        }

                        while ((Right_Front_Distance < (Optimal_Side_Distance_For_Center_Robot - 50)) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(left_and_right_motor_speed - 10, left_and_right_motor_speed + 10);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Right_Back_Distance = Read_Right_Back_Distance();
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }
        }

        Stop_Robot();

        if (founded_black_or_gray_tiles == true)
        {
                Go_Back();
                delay(2000);
                Stop_Robot();
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
        }
        else
        {
                Find_and_Rotate_To_Opend_Wall();
        }

        // I need sensors with correct range
        /*
        if (Is_Wall_Left())
        {
                //Align robot toward left wall
        }
        else if (Is_Wall_Right())
        {
                // Alilgn robot toward right wall
        }
        
        */
        founded_black_or_gray_tiles = false; //Condition for entering in autonomus loop
}

//######################################################################################################
//######################################################################################################
//######################################################################################################
//######################################################################################################
//#####################################    MAIN ROBOT FUNCTION    ######################################
//######################################################################################################
//######################################################################################################
//######################################################################################################
//######################################################################################################

void ROBOT_GIBANJE::Go_Autonomus_Adventage_Version(int Orientation_Tolerance = 1, int delayTime = 0)
{
        //added PID Gyorscope controller
        //added side wall P regulaor avoidance
        //added speed optimization depending gyroscope z orientation
        //added Serial communication with Raspberry

        // Define left and right motor speen when robot goes forward
        int left_and_right_motor_speed = 20;
        // Define variable for read orientation in real time
        int Current_Orientation;

        //Check is something arrived from Rapberry via serial communication
        if (Serial.available() > 0)
        {
                //Define variable for read string to the new line sign
                String data = Serial.readStringUntil('\n');

                //Check is H-character is recognised
                if (data.substring(0) == "HFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is S-character is recognised
                if (data.substring(0) == "SFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is S-character is recognised
                if (data.substring(0) == "UFND")
                {
                        Stop_Robot();
                        delay(5000);
                }
                //Check is main program on Raspberry Pi ended
                if (data.substring(0) == "STOP!")
                {
                        bool StopRobot = true;
                        while (StopRobot == true)
                        {
                                Stop_Robot();
                                delay(1000);
                        }
                }
        }
        // Define variable for floor tiles recognition (for now only black color), check code of Search_for_Black_or_Grey_tiles()
        boolean founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
        //Increase default motor speed if robot detect tilt up tile or small bumps, check code of Optimize_speed_with_Z_Orientation()
        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
        //Check is Temperature victim founded
        Read_Temperature_Left_Sensor();
        //Decide orientation which robot will follow
        Setpoint1 = Read_Gyroscope_X_Axis_Orientation();

        Serial.println(" ");
        Serial.println("#################################################");
        Serial.println("Decided orientation: ");
        Serial.println(Setpoint1);
        Serial.println("Maybe the wall is in the front of robot.");
        Serial.println("#################################################");
        Serial.println(" ");
        //Delay time slows speed serial print functions, and they became readible for humans
        delay(delayTime);
        //Multitasking variables used for testing a lot of situations
        int time_1 = millis();
        int time_2 = millis();
        //Define variables and read distance sensors
        int Forward_Left_distance = Read_Forward_Left_Distance();
        int Forward_Right_distance = Read_Forward_Right_Distance();

        int Left_Front_Distance = Read_Left_Front_Distance();
        int Left_Back_Distance = Read_Left_Back_Distance();

        int Right_Front_Distance = Read_Right_Front_Distance();
        int Right_Back_Distance = Read_Right_Back_Distance();

        //Main loop of program

        while ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false)) //condition - probably encoder distance
        {
                if (Serial.available() > 0)
                {

                        String data = Serial.readStringUntil('\n');

                        if (data.substring(0) == "HFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "SFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "UFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "STOP!")
                        {
                                bool StopRobot = true;
                                while (StopRobot == true)
                                {
                                        Stop_Robot();
                                        delay(1000);
                                }
                        }
                }

                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                delay(100);
                Read_Temperature_Left_Sensor();

                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                Left_Front_Distance = Read_Left_Front_Distance();
                Left_Back_Distance = Read_Left_Back_Distance();

                Right_Front_Distance = Read_Right_Front_Distance();
                Right_Back_Distance = Read_Right_Back_Distance();

                //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ");
                        Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(32 - Left_Front_Distance, 15);
                        delay(100);
                        Left_Front_Distance = Read_Left_Back_Distance();
                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();
                }

                //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ");
                        Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(15, 32 - Right_Front_Distance);
                        delay(100);
                        Right_Front_Distance = Read_Right_Front_Distance();
                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();
                }

                if (Serial.available() > 0)
                {

                        String data = Serial.readStringUntil('\n');

                        if (data.substring(0) == "HFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "SFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "UFND")
                        {
                                Stop_Robot();
                                delay(5000);
                        }
                        if (data.substring(0) == "STOP!")
                        {
                                bool StopRobot = true;
                                while (StopRobot == true)
                                {
                                        Stop_Robot();
                                        delay(1000);
                                }
                        }
                }
                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                Read_Temperature_Left_Sensor();
                Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                //Dio za provijeru koliko se robot zadržava u prethodnoj petlji
                Serial.println(time_2 - time_1);
                time_2 = millis();
                //Provjera trenutne orijentacije robota u odnosu na x-os naznačenu na žiroskopu
                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                //Provjera u kojem dijelu glavne petlje se nalazimo i ispis potrebnih uvijeta
                Serial.println(" ");
                Serial.println("I 'am in first while loop.");
                Serial.println("Current orientation 1st time: ");
                Serial.println(Current_Orientation);
                Serial.println(" ");
                delay(delayTime);

                //Interpolacije žiroskopa
                if ((Setpoint1 >= 0) && (Setpoint1 <= 89) && (founded_black_or_gray_tiles == false))
                {
                        int Setpoint1_Temp = Setpoint1 + 360;

                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                        {

                                Current_Orientation = Current_Orientation + 360;
                        }
                        else
                        {
                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println("Error is: ");
                        Serial.println(Current_Orientation - Setpoint1_Temp);
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                // Željena orijentacija se nalazi lijevo od trenutne orijentacije stoga se robot pomoću P-regulatora rotora u lijevo
                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                // Interpolacija identična prethonoj, vezana za ovu while petlju
                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();

                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }
                                // Current orientation je 499, kako?
                                Serial.println("Current orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();

                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else if ((Setpoint1 >= 271) && (Setpoint1 <= 360) && (founded_black_or_gray_tiles == false))
                {
                        int Setpoint1_Temp = Setpoint1 - 360;
                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                        {

                                Current_Orientation = Current_Orientation - 360;
                        }
                        else
                        {

                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in ELSE IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in ELSE IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println(" ");
                        delay(delayTime);

                        while ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();

                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else
                {
                        while (((Current_Orientation - Setpoint1) > Orientation_Tolerance) && (founded_black_or_gray_tiles == false))
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();

                                Serial.println("######### GO LEFT #########");
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        while ((Current_Orientation - Setpoint1) < -Orientation_Tolerance)
                        {
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Serial.println("######### GO RIGHT #########");
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);
                        }
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Read_Temperature_Left_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");
                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida

                        while ((Left_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO RIGHT - Too closed to Leftt wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(32 - Left_Front_Distance, 15);
                                delay(100);
                                Left_Front_Distance = Read_Left_Back_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        while ((Right_Front_Distance <= 12) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ");
                                Serial.println("GO LEFT - Too closed to Right wall. #########################################################");
                                Serial.println(" ");
                                if (Serial.available() > 0)
                                {

                                        String data = Serial.readStringUntil('\n');

                                        if (data.substring(0) == "HFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "SFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "UFND")
                                        {
                                                Stop_Robot();
                                                delay(5000);
                                        }
                                        if (data.substring(0) == "STOP!")
                                        {
                                                bool StopRobot = true;
                                                while (StopRobot == true)
                                                {
                                                        Stop_Robot();
                                                        delay(1000);
                                                }
                                        }
                                }
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                                Read_Temperature_Left_Sensor();
                                Go_Forward(15, 32 - Right_Front_Distance);
                                delay(100);
                                Right_Front_Distance = Read_Right_Front_Distance();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();
                        }

                        if (Serial.available() > 0)
                        {

                                String data = Serial.readStringUntil('\n');

                                if (data.substring(0) == "HFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "SFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "UFND")
                                {
                                        Stop_Robot();
                                        delay(5000);
                                }
                                if (data.substring(0) == "STOP!")
                                {
                                        bool StopRobot = true;
                                        while (StopRobot == true)
                                        {
                                                Stop_Robot();
                                                delay(1000);
                                        }
                                }
                        }
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }
        }

        Stop_Robot();

        if (founded_black_or_gray_tiles == true)
        {
                Go_Back();
                delay(2000);
                Stop_Robot();
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
                Rotate_Left_With_Specific_Angle(45);
        }
        else
        {
                Align_To_Front_Wall();
                Find_and_Rotate_To_Opend_Wall();

                if (Stopped_Is_Wall_Left_AND_Logic())
                {
                        Align_To_Left_Wall();
                }
                else if (Stopped_Is_Wall_Right_AND_Logic())
                {
                        Align_To_Right_Wall();
                }
        }

        founded_black_or_gray_tiles = false; //Condition for entering in autonomus loop
}

//######################################################################################################
//######################################################################################################
//######################################################################################################
//######################################################################################################
//#####################################    MAIN ROBOT FUNCTION    ######################################
//######################################################################################################
//######################################################################################################
//######################################################################################################
//######################################################################################################

void ROBOT_GIBANJE::Go_Autonomus_Adventage_Version_Optimized(int Orientation_Tolerance = 1, boolean Avoid_Side_Walls_P_Regulator_Turned_On = true, boolean Keep_Optimal_Distance_With_Side_Walls_P_Regulator_Turned_On = false, boolean Optimize_Speed_With_Z_Axis_Value_P_Regulator_Turned_On = true, int delayTime = 0)
{
        // added follow gyorscope P-regulator
        // added side wall avoidance P-regulaor
        // added keep optimal distance from side walls P-regulaor
        // added speed optimization depending gyroscope z orientation P-regulaor
        // added Serial communication with Raspberry

        // add DigitalWrite, and DigitalRead speed functions

        // Define left and right motor speen when robot goes forward
        int left_and_right_motor_speed = 20;
        // Define variable for read orientation in real time
        int Current_Orientation;
        //Check is something arrived from Rapberry via serial communication
        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
        // Define variable for floor tiles recognition (for now only black color), check code of Search_for_Black_or_Grey_tiles()
        boolean founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
        //Increase default motor speed if robot detect tilt up tile or small bumps, check code of Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop()
        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
        //Check is Temperature victim founded
        Read_Temperature_Left_Sensor();
        Read_Temperature_Right_Sensor();
        //Decide orientation which robot will follow
        Setpoint1 = Read_Gyroscope_X_Axis_Orientation();
        Serial.println(" ");
        Serial.println("#################################################");
        Serial.println("Decided orientation: ");
        Serial.println(Setpoint1);
        Serial.println("Maybe the wall is in the front of robot.");
        Serial.println("#################################################");
        Serial.println(" ");
        //Delay time slows speed serial print functions, and they became readible for humans
        delay(delayTime);
        //Multitasking variables used for testing a lot of situations
        int time_1 = millis();
        int time_2 = millis();

        //Define variables and read distance sensors
        int Forward_Left_distance = Read_Forward_Left_Distance();
        int Forward_Right_distance = Read_Forward_Right_Distance();

        int Left_Front_Distance = Read_Left_Front_Distance();
        int Left_Back_Distance = Read_Left_Back_Distance();

        int Right_Front_Distance = Read_Right_Front_Distance();
        int Right_Back_Distance = Read_Right_Back_Distance();

        //Main loop of program

        while ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false)) //condition - probably encoder distance
        {
                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                Forward_Left_distance = Read_Forward_Left_Distance();
                Forward_Right_distance = Read_Forward_Right_Distance();

                Left_Front_Distance = Read_Left_Front_Distance();
                Left_Back_Distance = Read_Left_Back_Distance();

                Right_Front_Distance = Read_Right_Front_Distance();
                Right_Back_Distance = Read_Right_Back_Distance();

                //#################################### P - regulatori #############################################################################################################################################################

                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                //#################################################################################################################################################################################################################

                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                Read_Temperature_Left_Sensor();
                Read_Temperature_Right_Sensor();

                //Dio za provijeru koliko se robot zadržava u prethodnoj petlji
                Serial.println(time_2 - time_1);
                time_2 = millis();
                //Provjera trenutne orijentacije robota u odnosu na x-os naznačenu na žiroskopu
                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());
                //Provjera u kojem dijelu glavne petlje se nalazimo i ispis potrebnih uvijeta
                Serial.println(" ");
                Serial.println("I 'am in first while loop.");
                Serial.println("Current orientation 1st time: ");
                Serial.println(Current_Orientation);
                Serial.println(" ");
                delay(delayTime);

                //Interpolacije žiroskopa
                if ((Setpoint1 >= 0) && (Setpoint1 <= 89) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" IF CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        int Setpoint1_Temp = Setpoint1 + 360;

                        if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                        {

                                Current_Orientation = Current_Orientation + 360;
                        }
                        else
                        {
                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println("Error is: ");
                        Serial.println(Current_Orientation - Setpoint1_Temp);
                        delay(delayTime);

                        // Go Left giroscope error P - regulator
                        int wtgf = 600;
                        int Gyro_Regulator_Start_Time = millis();
                        int Gyro_Regulator_End_Time = millis();
                        int running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" IF CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");

                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                // Željena orijentacija se nalazi lijevo od trenutne orijentacije stoga se robot pomoću P-regulatora rotora u lijevo
                                Serial.println("######### Go Left giroscope error P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);
                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                // Interpolacija identična prethonoj, vezana za ovu while petlju
                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }
                        Serial.println(" IF CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        // Go Right giroscope error P - regulator
                        wtgf = 600;
                        Gyro_Regulator_Start_Time = millis();
                        Gyro_Regulator_End_Time = millis();
                        running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;

                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" IF CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                Serial.println("######### GO RIGHT GIROSCOPE ERROR P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 0) && (Current_Orientation <= 89))
                                {

                                        Current_Orientation = Current_Orientation + 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }
                                // Current orientation je 499, kako?
                                Serial.println("Current orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }
                        Serial.println(" IF CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                //Interpolacije žiroskopa
                else if ((Setpoint1 >= 271) && (Setpoint1 <= 360) && (Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ELSE IF 1ST CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");
                        int Setpoint1_Temp = Setpoint1 - 360;
                        Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                        if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                        {

                                Current_Orientation = Current_Orientation - 360;
                        }
                        else
                        {

                                Current_Orientation = Current_Orientation;
                        }

                        Serial.println("Current orientation in ELSE IF condition: ");
                        Serial.println(Current_Orientation);
                        Serial.println("Decided orientation in ELSE IF condition: ");
                        Serial.println(Setpoint1_Temp);
                        Serial.println(" ");
                        delay(delayTime);

                        // Go Left giroscope error P - regulator
                        int wtgf = 600;
                        int Gyro_Regulator_Start_Time = millis();
                        int Gyro_Regulator_End_Time = millis();
                        int running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1_Temp) > Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ELSE IF 1ST CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                Serial.println("######### Go Left giroscope error P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }
                        Serial.println(" ELSE IF 1ST CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");
                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        // Go Right giroscope error P - regulator
                        wtgf = 600;
                        Gyro_Regulator_Start_Time = millis();
                        Gyro_Regulator_End_Time = millis();
                        running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1_Temp) < -Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ELSE IF 1ST CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");
                                int error = Current_Orientation - Setpoint1_Temp;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                Serial.println("######### GO RIGHT GIROSCOPE ERROR P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                if ((Current_Orientation >= 271) && (Current_Orientation <= 360))
                                {

                                        Current_Orientation = Current_Orientation - 360;
                                }
                                else
                                {
                                        Current_Orientation = Current_Orientation;
                                }

                                Serial.println("Current orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1_Temp);
                                Serial.println("Current EROR in ELSE IF 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1_Temp);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }
                        Serial.println(" ELSE IF 1ST CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");
                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else if ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot) && (founded_black_or_gray_tiles == false))
                {
                        Serial.println(" ELSE IF 2ND CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        // Go Left giroscope error P - regulator
                        int wtgf = 600;
                        int Gyro_Regulator_Start_Time = millis();
                        int Gyro_Regulator_End_Time = millis();
                        int running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1) > Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ELSE IF 2ND CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                Serial.println("######### Go Left giroscope error P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed - error, left_and_right_motor_speed + error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 1st WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 1st WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }

                        Serial.println(" ELSE IF 2ND CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");
                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        // Go Right giroscope error P - regulator
                        wtgf = 600;
                        Gyro_Regulator_Start_Time = millis();
                        Gyro_Regulator_End_Time = millis();
                        running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        while ((running_function_time_interval < wtgf) && ((Current_Orientation - Setpoint1) < -Orientation_Tolerance) && ((Forward_Left_distance > Optimal_Stop_Front_Distance_For_Center_Robot) || (Forward_Right_distance > Optimal_Stop_Front_Distance_For_Center_Robot)) && (founded_black_or_gray_tiles == false))
                        {
                                Serial.println(" ELSE IF 2ND CONDITION OF MAIN LOOP.");
                                Serial.println("_________________________________________________________________________________________________________.");
                                int error = Current_Orientation - Setpoint1;

                                if (error < 0)
                                {
                                        error = error * (-1);
                                }

                                Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                                founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                                left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                                Read_Temperature_Left_Sensor();
                                Read_Temperature_Right_Sensor();
                                Forward_Left_distance = Read_Forward_Left_Distance();
                                Forward_Right_distance = Read_Forward_Right_Distance();

                                Serial.println("######### GO RIGHT GIROSCOPE ERROR P - regulator #########");
                                Serial.println("Giroscope Error: ");
                                Serial.println(error);
                                Serial.println("___________________________________________ ");
                                if (error < 15)
                                {
                                        error = 3;
                                }
                                Go_Forward(left_and_right_motor_speed + error, left_and_right_motor_speed - error);

                                Current_Orientation = int(Read_Gyroscope_X_Axis_Orientation());

                                Serial.println("Current orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation);
                                Serial.println("Decided orientation in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Setpoint1);
                                Serial.println("Current EROR in ELSE 2nd WHILE LOOP: ");
                                Serial.println(Current_Orientation - Setpoint1);
                                Serial.println(" ");
                                delay(delayTime);

                                Gyro_Regulator_End_Time = millis();
                                running_function_time_interval = Gyro_Regulator_End_Time - Gyro_Regulator_Start_Time;
                        }
                        Serial.println(" ELSE IF 2ND CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);

                        Serial.println("Fobot follow gyroscope.");
                        Serial.println(" ");

                        Forward_Left_distance = Read_Forward_Left_Distance();
                        Forward_Right_distance = Read_Forward_Right_Distance();

                        Left_Front_Distance = Read_Left_Front_Distance();
                        Left_Back_Distance = Read_Left_Back_Distance();

                        Right_Front_Distance = Read_Right_Front_Distance();
                        Right_Back_Distance = Read_Right_Back_Distance();

                        Serial.println("----------------------------------");
                        Serial.println("LEFT --- FRONT --- RIGHT");
                        Serial.print(Left_Front_Distance);
                        Serial.print(" ");
                        Serial.print(Left_Back_Distance);
                        Serial.print(" : ");
                        Serial.print(Forward_Left_distance);
                        Serial.print(" ");
                        Serial.print(Forward_Right_distance);
                        Serial.print(" : ");
                        Serial.print(Right_Front_Distance);
                        Serial.print(" ");
                        Serial.println(Right_Back_Distance);
                        Serial.println("----------------------------------");

                        //Pod-petlja koja pomijera robot u desno kada je blizu lijevog zida
                        Stay_Away_From_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja pomijera robot u lijevo kada je blizu desnog zida
                        Stay_Away_From_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s lijevim zidom
                        Keep_Optimal_Distance_With_Left_Wall_Optimized_For_Autonomus_Loop(Left_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);
                        //Pod-petlja koja održava optimalnu udaljenost s desnim zidom
                        Keep_Optimal_Distance_With_Right_Wall_Optimized_For_Autonomus_Loop(Right_Front_Distance, Forward_Left_distance, Forward_Right_distance, founded_black_or_gray_tiles, left_and_right_motor_speed);

                        Listen_Serial_Port_Optimized_For_Autonomus_Loop();
                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();
                        left_and_right_motor_speed = Optimize_speed_with_Z_Orientation_Optimized_For_Autonomus_Loop();
                        Read_Temperature_Left_Sensor();
                        Read_Temperature_Right_Sensor();
                        Go_Forward(left_and_right_motor_speed, left_and_right_motor_speed);
                }

                else
                {
                        Serial.println("ELSE CONDITION OF MAIN LOOP.");
                        Serial.println("_________________________________________________________________________________________________________.");

                        founded_black_or_gray_tiles = Search_for_Black_or_Grey_tiles();

                        if (Stopped_Is_Wall_Left_AND_Logic())
                        {
                                Align_To_Left_Wall();
                        }
                        else if (Stopped_Is_Wall_Right_AND_Logic())
                        {
                                Align_To_Right_Wall();
                        }
                        else if (Stopped_Is_Wall_Forward_AND_Logic())
                        {
                                Align_To_Front_Wall();
                        }
                        else
                        {
                                Rotate_Left_With_Specific_Angle(10);
                        }
                }
        }

        Stop_Robot();

        if (founded_black_or_gray_tiles == true)
        {
                Go_Back();
                delay(2000);
                Stop_Robot();
                Rotate_Robot_For_180_degrees();
        }
        else
        {
                Align_To_Front_Wall();
                Find_and_Rotate_To_Opend_Wall();

                if (Stopped_Is_Wall_Left_AND_Logic())
                {
                        Align_To_Left_Wall();
                }
                else if (Stopped_Is_Wall_Right_AND_Logic())
                {
                        Align_To_Right_Wall();
                }
        }

        founded_black_or_gray_tiles = false; //Condition for entering in autonomus loop
}